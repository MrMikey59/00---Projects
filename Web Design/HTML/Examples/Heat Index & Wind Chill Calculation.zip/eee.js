var initialsub2="re: About EasySurf"
var zx4="easysurf@"
var zx5="easysurf.cc"
function mail2Url() {
window.location = "mailto:"+ zx4 + zx5 +"?subject="+initialsub2
   }